<?php $__env->startSection('content'); ?>
<!-- jQuery -->
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <h1 class="display-4">Expense</h1>
        </div>
        <div class="col-md-6 text-md-right mt-3">
            <a class="btn btn-primary btn-sm" data-title="<?php echo e(('Add Income')); ?>"
                href="<?php echo e(route('expense.create')); ?>">
                <i class="fas fa-plus"></i> <?php echo e(('Add New')); ?>

            </a>
        </div>
    </div>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Accounting</li>
            <li class="breadcrumb-item active" aria-current="page">Transactions</li>
            <li class="breadcrumb-item active" aria-current="page">Expense</li>
        </ol>
    </nav>
<div class="row">
    <div class="col-md-12">
        
          <div class="card-body">
          <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th><?php echo e(_lang('Date')); ?></th>
                            <th><?php echo e(_lang('Account')); ?></th>
                            <th><?php echo e(_lang('Expense Type')); ?></th>
                            <th class="text-right"><?php echo e(_lang('Amount')); ?></th>
                            <th><?php echo e(_lang('Payee')); ?></th>
                            <th><?php echo e(_lang('Payment Method')); ?></th>
                            <th class="action-col"><?php echo e(_lang('Action')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($transaction->trans_date); ?></td>
                <td><?php echo e($transaction->account->account_title); ?></td>
                <td><?php echo e($transaction->expense_type->name); ?></td>
                <td><?php echo e(decimalPlace($transaction->amount, $currency)); ?></td>
                <td><?php echo e($transaction->payee->contact_name ?? ''); ?></td>
                <td><?php echo e($transaction->payment_method->name ?? ''); ?></td>
    
                <td>
                    <?php if(isset($transaction->income_type->name)): ?>
                    <form action="<?php echo e(action('App\Http\Controllers\ExpenseController@destroy', $transaction->id)); ?>" class="text-center" method="post">
                    <div class="btn-group" role="group" aria-label="Basic example">           <a href="<?php echo e(action('App\Http\Controllers\ExpenseController@edit', $transaction->id)); ?>" data-title="<?php echo e(_lang('Update Income')); ?>" class="btn btn-warning btn-sm ajax-modal"><i class="fas fa-pen"></i></a>
                        <a href="<?php echo e(action('App\Http\Controllers\ExpenseController@show', $transaction->id)); ?>" data-title="<?php echo e(_lang('View Income')); ?>" class="btn btn-info btn-sm ajax-modal"><i class="fas fa-eye"></i></a>
                        <?php echo csrf_field(); ?>
                        <input name="_method" type="hidden" value="DELETE">
                        <button class="btn btn-danger btn-sm btn-remove" type="submit"><i class="fas fa-trash"></i></button>
                        </div>   </form>
                    <?php else: ?>
                    <form action="<?php echo e(action('App\Http\Controllers\ExpenseController@destroy', $transaction->id)); ?>" class="text-center" method="post">
                    <div class="btn-group" role="group" aria-label="Basic example">         <a href="#" data-title="<?php echo e(_lang('Update Income')); ?>" class="btn btn-warning btn-sm ajax-modal" disabled><i class="fas fa-pen"></i></a>
                        <a href="<?php echo e(action('App\Http\Controllers\ExpenseController@show', $transaction->id)); ?>" data-title="<?php echo e(_lang('View Income')); ?>" class="btn btn-info btn-sm ajax-modal"><i class="fas fa-eye"></i></a>
                        <?php echo csrf_field(); ?>
                        <input name="_method" type="hidden" value="DELETE">
                        <button class="btn btn-danger btn-sm btn-remove" type="submit"><i class="fas fa-trash"></i></button>
                        </div> </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/expense/list.blade.php ENDPATH**/ ?>