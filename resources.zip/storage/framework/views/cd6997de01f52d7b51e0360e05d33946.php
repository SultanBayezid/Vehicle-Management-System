<?php $__env->startSection('content'); ?>
<div class="container">
        <h1 class="display-4"><?php echo e(_lang('Account Details')); ?></h1>

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item active"  aria-current="page">Accounting</li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('accounts.index')); ?>">Accounts</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e(_lang('Account Details')); ?></li>
            </ol>
        </nav>
<div class="row">
    <div class="col-md-12">
    <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <td><?php echo e(_lang('Account Title')); ?></td>
                        <td><?php echo e($account->account_title); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(_lang('Opening Date')); ?></td>
                        <td><?php echo e($account->opening_date); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(_lang('Account Number')); ?></td>
                        <td><?php echo e($account->account_number); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(_lang('Opening Balance')); ?></td>
                        <td><?php echo e(decimalPlace($account->opening_balance, currency())); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(_lang('Note')); ?></td>
                        <td><?php echo e($account->note); ?></td>
                    </tr>
                </table>
            </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/account/view.blade.php ENDPATH**/ ?>