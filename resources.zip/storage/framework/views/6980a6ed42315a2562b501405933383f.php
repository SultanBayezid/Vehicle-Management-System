

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
                        <h1 class="mt-4">Drivers</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Drivers</li>
                            <li  class="breadcrumb-item">
                            <a href="<?php echo e(route('drivers.create')); ?>" class="btn btn-primary">Create New Driver</a>

                            </li>
                        </ol>
                    
                        <div class="card mb-4">
                            <!-- <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                DataTable Example
                            </div> -->
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>License Number</th>
                                            <th>License Expiry Date</th>
                                            <th>Phone Number</th>
                                            <th>Blood Group:</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                        <th>Name</th>
                                            <th>License Number</th>
                                            <th>License Expiry Date</th>
                                            <th>Phone Number</th>
                                            <th>Blood Group:</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($driver->name); ?></td>
                                            <td><?php echo e($driver->license_number); ?></td>
                                            <td><?php echo e($driver->license_expiry_date); ?></td>
                                            <td><?php echo e($driver->phone_number); ?></td>
                                            <td><?php echo e($driver->blood_group); ?></td>
                                     
                                            <td>
                <a href="<?php echo e(route('drivers.show', $driver->id)); ?>" class="btn btn-info btn-sm">View</a>
                <a href="<?php echo e(route('drivers.edit', $driver->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                <form method="POST" action="<?php echo e(route('drivers.destroy', $driver->id)); ?>" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this Driver?')">Delete</button>
                </form>
            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                             
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/drivers/index.blade.php ENDPATH**/ ?>