<?php $__env->startSection('content'); ?>
<div class="container">
        <h1 class="display-4"><?php echo e(_lang('View Expense')); ?></h1>

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item">Accounting</li>
                <li class="breadcrumb-item"><?php echo e(('Transactions')); ?></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('expense.index')); ?>">Expense</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e(_lang('View Expense')); ?></li>
            </ol>
        </nav>
<div class="row">
    <div class="col-md-12">
    <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <td><?php echo e(_lang('Trans Date')); ?></td>
                        <td><?php echo e($transaction->trans_date); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(_lang('Account')); ?></td>
                        <td><?php echo e($transaction->account->account_title); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(_lang('Expense Type')); ?></td>
                        <td><?php echo e(isset($transaction->expense_type->name) ? $transaction->expense_type->name : _lang('Transfer')); ?>

                        </td>
                    </tr>
                    <tr>
                        <td><?php echo e(_lang('Amount')); ?></td>
                        <td><?php echo e(decimalPlace($transaction->amount, currency())); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(_lang('Payee')); ?></td>
                        <td><?php echo e($transaction->payee->contact_name); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(_lang('Payment Method')); ?></td>
                        <td><?php echo e($transaction->payment_method->name); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(_lang('Reference')); ?></td>
                        <td><?php echo e($transaction->reference); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo e(_lang('Attachment')); ?></td>
                        <td>
                            <?php if($transaction->attachment != ""): ?>
                            <a href="<?php echo e(asset('public/uploads/transactions/'.$transaction->attachment)); ?>"
                                target="_blank" class="btn btn-primary btn-sm"><?php echo e(_lang('View Attachment')); ?></a>
                            <?php else: ?>
                            <label class="label label-warning">
                                <strong><?php echo e(_lang('No Atachment Available !')); ?></strong>
                            </label>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td><?php echo e(_lang('Note')); ?></td>
                        <td><?php echo e($transaction->note); ?></td>
                    </tr>
                </table>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/expense/view.blade.php ENDPATH**/ ?>