<?php $__env->startSection('content'); ?>
<!-- jQuery -->
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <h1 class="display-4"><?php echo e(_lang('Update Account')); ?></h1>
        </div>
        <div class="col-md-6 text-md-right mt-3">
            <a class="btn btn-primary btn-sm" data-title="<?php echo e(('Add Income')); ?>"
                href="<?php echo e(route('accounts.create')); ?>">
                <i class="fas fa-plus"></i> <?php echo e(('Add New')); ?>

            </a>
        </div>
    </div>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Accounting</li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('accounts.index')); ?>">Accounts</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e(_lang('Update Account')); ?></li>
        </ol>
    </nav>
<div class="row">
    <div class="col-md-12">
   
       
            <div class="card-body">
            <form method="post" class="validate" autocomplete="off" action="<?php echo e(action('App\Http\Controllers\AccountController@update', $id)); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <input name="_method" type="hidden" value="PATCH">

    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <label class="control-label"><?php echo e(_lang('Account Title')); ?></label>
                <input type="text" class="form-control" name="account_title" value="<?php echo e($account->account_title); ?>" required>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="form-group">
                <label class="control-label"><?php echo e(_lang('Opening Date')); ?></label>
                <input type="date" class="form-control datepicker" name="opening_date" value="<?php echo e($account->opening_date); ?>" required>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6">
            <div class="form-group">
                <label class="control-label"><?php echo e(_lang('Account Number')); ?></label>
                <input type="text" class="form-control" name="account_number" value="<?php echo e($account->account_number); ?>">
            </div>
        </div>

        <div class="col-lg-6">
            <div class="form-group">
                <label class="control-label"><?php echo e(_lang('Opening Balance')." ".currency()); ?></label>
                <input type="text" class="form-control float-field" name="opening_balance" value="<?php echo e($account->opening_balance); ?>" disabled>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label class="control-label"><?php echo e(_lang('Note')); ?></label>
                <textarea class="form-control" name="note"><?php echo e($account->note); ?></textarea>
            </div>
        </div>
    </div>

    <div class="form-group">
        <div class="col-md-12">
            <button type="submit" class="btn btn-primary btn-sm"><i class="ti-save"></i> <?php echo e(_lang('Save Changes')); ?></button>
        </div>
    </div>
</form>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/account/edit.blade.php ENDPATH**/ ?>