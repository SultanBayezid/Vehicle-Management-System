<?php $__env->startSection('content'); ?>
<div class="container">
        <h1 class="display-4"><?php echo e(('Add Income/Expense Type')); ?></h1>

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item">Transactions</li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('chart_of_accounts.index')); ?>"><?php echo e(('Income/Expense Type')); ?></a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e(('Add Income/Expense Type')); ?></li>
            </ol>
        </nav>
<div class="row">
    <div class="col-md-12">
    <div class="card-body">
                <div class="col-md-12">
                    <form method="post" class="validate" autocomplete="off"
                        action="<?php echo e(route('chart_of_accounts.store')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="control-label"><?php echo e(('Name')); ?></label>
                                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>"
                                        required>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="control-label"><?php echo e(('Type')); ?></label>
                                    <select class="form-control" name="type" required>
                                        <option value="income"><?php echo e(('Income')); ?></option>
                                        <option value="expense"><?php echo e(('Expense')); ?></option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-sm"><i class="ti-save"></i>
                                        <?php echo e(('Save')); ?></button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/chart_of_account/create.blade.php ENDPATH**/ ?>