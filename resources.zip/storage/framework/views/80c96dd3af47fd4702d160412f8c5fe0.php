<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card card-default">
            <div class="card-header">
                <h4 class="header-title"><?php echo e(_lang('Update Payment Method')); ?></h4>
            </div>

            <div class="card-body">
                <div class="col-md-6">
                    <form method="post" class="validate" autocomplete="off"
                        action="<?php echo e(action('App\Http\Controllers\PaymentMethodController@update', $id)); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input name="_method" type="hidden" value="PATCH">

                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="control-label"><?php echo e(_lang('Name')); ?></label>
                                <input type="text" class="form-control" name="name" value="<?php echo e($paymentmethod->name); ?>"
                                    required>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-lg"><i class="ti-save"></i>
                                    <?php echo e(_lang('Update')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/payment_method/edit.blade.php ENDPATH**/ ?>