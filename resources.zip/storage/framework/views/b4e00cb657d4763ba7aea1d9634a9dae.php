<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header d-flex align-items-center">
				<h4 class="header-title"><?php echo e(_lang('Payment Methods')); ?></h4>
                <a class="btn btn-primary btn-sm ml-auto ajax-modal" data-title="<?php echo e(_lang('Add Payment Method')); ?>"
                    href="<?php echo e(route('payment_methods.create')); ?>"><i class="ti-plus"></i> <?php echo e(_lang('Add New')); ?></a>
            </div>

            <div class="card-body">
                <table class="table table-bordered data-table">
                    <thead>
                        <tr>
                            <th><?php echo e(_lang('Name')); ?></th>
                            <th class="action-col"><?php echo e(_lang('Action')); ?></th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $paymentmethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentmethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="row_<?php echo e($paymentmethod->id); ?>">
                            <td class='name'><?php echo e($paymentmethod->name); ?></td>
                            <td class="text-center">
                                <form action="<?php echo e(action('App\Http\Controllers\PaymentMethodController@destroy', $paymentmethod['id'])); ?>"
                                    method="post">
                                    <a href="<?php echo e(action('App\Http\Controllers\PaymentMethodController@edit', $paymentmethod['id'])); ?>"
                                        data-title="<?php echo e(_lang('Update Payment Method')); ?>"
                                        class="btn btn-warning btn-sm ajax-modal"><i class="ti-pencil-alt"></i></a>
                                    <?php echo e(csrf_field()); ?>

                                    <input name="_method" type="hidden" value="DELETE">
                                    <button class="btn btn-danger btn-sm btn-remove"
                                        type="submit"><i class="ti-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/payment_method/list.blade.php ENDPATH**/ ?>