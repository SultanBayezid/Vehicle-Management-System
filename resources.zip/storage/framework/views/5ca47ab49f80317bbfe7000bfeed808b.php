<?php $__env->startSection('content'); ?>
<!-- jQuery -->
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <h1 class="display-4">Accounts</h1>
        </div>
        <div class="col-md-6 text-md-right mt-3">
            <a class="btn btn-primary btn-sm" data-title="<?php echo e(('Add Income')); ?>"
                href="<?php echo e(route('accounts.create')); ?>">
                <i class="fas fa-plus"></i> <?php echo e(('Add New')); ?>

            </a>
        </div>
    </div>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Accounting</li>
            <li class="breadcrumb-item active" aria-current="page">Accounts</li>
        </ol>
    </nav>
<div class="row">
    <div class="col-md-12">

    

            <div class="card-body">
            <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th><?php echo e(_lang('Account Title')); ?></th>
                            <th><?php echo e(_lang('Opening Date')); ?></th>
                            <th><?php echo e(_lang('Account Number')); ?></th>
                            <th class="text-right"><?php echo e(_lang('Opening Balance')); ?></th>
                            <th class="action-col"><?php echo e(_lang('Action')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $currency = currency(); ?>
						<?php $date_format = get_date_format(); ?>
                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="row_<?php echo e($account->id); ?>">
                            <td class='account_title'><?php echo e($account->account_title); ?></td>
                            <td class='opening_date'><?php echo e(date("$date_format", strtotime($account->opening_date))); ?></td>
                            <td class='account_number'><?php echo e($account->account_number); ?></td>
                            <td class='opening_balance text-right'>
                                <?php echo e(decimalPlace($account->opening_balance, $currency)); ?></td>
                            <td class="text-center">
                                <form action="<?php echo e(action('App\Http\Controllers\AccountController@destroy', $account->id)); ?>" method="post">
                                    <a href="<?php echo e(action('App\Http\Controllers\AccountController@edit', $account->id)); ?>"
                                        data-title="<?php echo e(_lang('Update Account')); ?>"
                                        class="btn btn-warning btn-sm ajax-modal"><i class="fas fa-pen"></i></a>
                                    <a href="<?php echo e(action('App\Http\Controllers\AccountController@show', $account->id)); ?>"
                                        data-title="<?php echo e(_lang('View Account')); ?>"
                                        class="btn btn-primary btn-sm ajax-modal"><i class="fas fa-eye"></i></a>
                                    <?php echo e(csrf_field()); ?>

                                    <input name="_method" type="hidden" value="DELETE">
                                    <button class="btn btn-danger btn-sm btn-remove"
                                        type="submit"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/account/list.blade.php ENDPATH**/ ?>