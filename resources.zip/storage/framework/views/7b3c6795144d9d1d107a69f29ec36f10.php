<?php $__env->startSection('content'); ?>
<div class="container">
        <h1 class="display-4"><?php echo e(_lang('Update Expense')); ?></h1>

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item">Accounting</li>
                <li class="breadcrumb-item"><?php echo e(('Transactions')); ?></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('expense.index')); ?>">Expense</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e(_lang('Update Expense')); ?></li>
            </ol>
        </nav>
<div class="row">
    <div class="col-md-12">
    <div class="card-body">
                <form method="post" class="validate" autocomplete="off"
                    action="<?php echo e(action('App\Http\Controllers\ExpenseController@update', $id)); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <input name="_method" type="hidden" value="PATCH">

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label"><?php echo e(_lang('Date')); ?></label>
                                <input type="date" class="form-control datepicker" name="trans_date"
                                    value="<?php echo e($transaction->getRawOriginal('trans_date')); ?>" required>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                             
                                <label class="control-label"><?php echo e(_lang('Account')); ?></label>
                                <select class="form-control select2-ajax" data-value="id" data-display="account_title"
                                    data-table="accounts" data-where="1" name="account_id" required>
                                    <option value=""><?php echo e(_lang('Select One')); ?></option>
                                    <?php echo e(create_option("accounts", "id", "account_title", $transaction->account_id)); ?>


                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                              
                                <label class="control-label"><?php echo e(_lang('Expense Type')); ?></label>
                                <select class="form-control select2-ajax" data-value="id" data-display="name"
                                    data-table="chart_of_accounts" data-where="4" name="chart_id" required>
                                    <option value=""><?php echo e(_lang('Select One')); ?></option>
                                    <?php echo e(create_option("chart_of_accounts", "id", "name", $transaction->chart_id, ["type=" => "expense"])); ?>


                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label"><?php echo e(_lang('Amount')." ".currency()); ?></label>
                                <input type="text" class="form-control float-field" name="amount"
                                    value="<?php echo e($transaction->amount); ?>" required>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                             
                                <label class="control-label"><?php echo e(_lang('Payee')); ?></label>
                                <select class="form-control select2-ajax" data-value="id" data-display="contact_name"
                                    data-table="contacts" data-where="1" name="payer_payee_id">
                                    <option value=""><?php echo e(_lang('Select One')); ?></option>
                                    <?php echo e(create_option("contacts", "id", "contact_name", $transaction->payer_payee_id)); ?>


                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                            
                                <label class="control-label"><?php echo e(_lang('Payment Method')); ?></label>
                                <select class="form-control select2-ajax" data-value="id" data-display="name"
                                    data-table="payment_methods" data-where="1" name="payment_method_id" required>
                                    <option value=""><?php echo e(_lang('Select One')); ?></option>
                                    <?php echo e(create_option("payment_methods", "id", "name", $transaction->payment_method_id)); ?>


                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label"><?php echo e(_lang('Reference')); ?></label>
                                <input type="text" class="form-control" name="reference"
                                    value="<?php echo e($transaction->reference); ?>">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="control-label"><?php echo e(_lang('Attachment')); ?></label>
                                <input type="file" class="form-control trickycode-file"
                                    data-value="<?php echo e($transaction->attachment); ?>" name="attachment">
                            </div>
                        </div>

                        <div class="col-md-12 clear">
                            <div class="form-group">
                                <label class="control-label"><?php echo e(_lang('Note')); ?></label>
                                <textarea class="form-control" name="note"><?php echo e($transaction->note); ?></textarea>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary"><i class="ti-save"></i>
                                    <?php echo e(_lang('Save Changes')); ?></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/expense/edit.blade.php ENDPATH**/ ?>