

<?php $__env->startSection('content'); ?>
<!-- jQuery -->
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <h1 class="display-4">Drivers</h1>
        </div>
        <div class="col-md-6 text-md-right mt-3">
            <a class="btn btn-primary btn-sm" data-title="<?php echo e(('Add Income')); ?>"
                href="<?php echo e(route('drivers.create')); ?>">
                <i class="fas fa-plus"></i> <?php echo e(('Add New')); ?>

            </a>
        </div>
    </div>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">People</li>
            <li class="breadcrumb-item active" aria-current="page">Drivers</li>
        </ol>
    </nav>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>License Number</th>
                                            <th>License Expiry Date</th>
                                            <th>Phone Number</th>
                                            <th>Blood Group:</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                        <th>Name</th>
                                            <th>License Number</th>
                                            <th>License Expiry Date</th>
                                            <th>Phone Number</th>
                                            <th>Blood Group:</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($driver->name); ?></td>
                                            <td><?php echo e($driver->license_number); ?></td>
                                            <td><?php echo e($driver->license_expiry_date); ?></td>
                                            <td><?php echo e($driver->phone_number); ?></td>
                                            <td><?php echo e($driver->blood_group); ?></td>
                                     
                                            <td>
                <a href="<?php echo e(route('drivers.show', $driver->id)); ?>" class="btn btn-info btn-sm">View</a>
                <a href="<?php echo e(route('drivers.edit', $driver->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                <form method="POST" action="<?php echo e(route('drivers.destroy', $driver->id)); ?>" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this Driver?')">Delete</button>
                </form>
            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                             
                                    </tbody>
                                </table>
                            </div>
                        </div>
            



<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/drivers/list.blade.php ENDPATH**/ ?>