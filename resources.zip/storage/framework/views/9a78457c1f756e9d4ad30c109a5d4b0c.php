<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <h1 class="display-4">Trips</h1>
        </div>
        <div class="col-md-6 text-md-right mt-3">
            <a class="btn btn-primary btn-sm" data-title="<?php echo e(('Add Income')); ?>"
                href="<?php echo e(route('trips.create')); ?>">
                <i class="fas fa-plus"></i> <?php echo e(('Add New')); ?>

            </a>
        </div>
    </div>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Trips</li>
        </ol>
    </nav>



    <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Customer</th>
                                            <th>Driver</th>
                                            <th>Vehicle</th>
                                            <th>Pickup Location</th>
                                            <th>Dropoff Location</th>
                                            <th>Fare</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                        <th>Date</th>
                                            <th>Customer</th>
                                            <th>Driver</th>
                                            <th>Vehicle</th>
                                            <th>Pickup Location</th>
                                            <th>Dropoff Location</th>
                                            <th>Fare</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($trip->trip_date); ?></td>
                                            <td><?php echo e($trip->customer->contact_name); ?></td>
                                            <td><?php echo e($trip->driver->name); ?></td>
                                            <td><?php echo e($trip->vehicle->make); ?></td>
                                            <td><?php echo e($trip->pickup_location); ?></td>
                                            <td><?php echo e($trip->dropoff_location); ?></td>
                                            <td><?php echo e($trip->fare_amount); ?></td>
                                     
                                        <td>
                                        <div class="btn-group" role="group" aria-label="Basic example">
                                            <a href="<?php echo e(route('trips.show', $trip->id)); ?>" class="btn btn-info btn-sm"><i class="fas fa-eye"></i></a>
                                        <a href="<?php echo e(route('trips.edit', $trip->id)); ?>" class="btn btn-warning btn-sm"><i class="fas fa-pen"></i></a>
                                        <form method="POST" action="<?php echo e(route('trips.destroy', $trip->id)); ?>" style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this Driver?')"><i class="fas fa-trash"></i></button>
                                        </form>
                                            </div>
                                    
                                          </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                             
                                    </tbody>
                                </table>
                            </div>
                    
                  
</div>
               



<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/trips/list.blade.php ENDPATH**/ ?>