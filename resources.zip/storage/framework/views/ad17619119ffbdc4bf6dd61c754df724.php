<?php $__env->startSection('content'); ?>
<!-- jQuery -->
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <h1 class="display-4"><?php echo e(('Income and Expense Types')); ?></h1>
        </div>
        <div class="col-md-6 text-md-right mt-3">
            <a class="btn btn-primary btn-sm" data-title="<?php echo e(('Add Income')); ?>"
                href="<?php echo e(route('chart_of_accounts.create')); ?>">
                <i class="fas fa-plus"></i> <?php echo e(('Add New')); ?>

            </a>
        </div>
    </div>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Accounting</li>
            <li class="breadcrumb-item active" aria-current="page">Accounts</li>
        </ol>
    </nav>
<div class="row">
    <div class="col-md-12">
            <div class="card-body">
            <table id="datatablesSimple" width="100%">
                    <thead>
                        <tr>
                            <th><?php echo e(('Name')); ?></th>
                            <th><?php echo e(('Type')); ?></th>
                            <th class="action-col"  width="5%"><?php echo e(('Action')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $chartofaccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chartofaccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="row_<?php echo e($chartofaccount->id); ?>">
                            <td class='name'><?php echo e($chartofaccount->name); ?></td>
                            <td class='type'><?php echo e((ucwords($chartofaccount->type))); ?></td>
                            <td class="text-center" width="5% !important">
                                <form action="<?php echo e(action('App\Http\Controllers\ChartOfAccountController@destroy', $chartofaccount['id'])); ?>"
                                    method="post">
                                    <div class="btn-group" role="group" aria-label="Basic example">  
                                    <a href="<?php echo e(action('App\Http\Controllers\ChartOfAccountController@edit', $chartofaccount['id'])); ?>"
                                        data-title="<?php echo e(('Update Income/Expense Type')); ?>"
                                        class="btn btn-warning btn-sm ajax-modal"><i class="fas fa-pen"></i></a>
                                    <?php echo e(csrf_field()); ?>

                                    <input name="_method" type="hidden" value="DELETE">
                                    <button class="btn btn-danger btn-sm btn-remove"
                                        type="submit"><i class="fas fa-trash"></i></button>
                                        </div>  </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/chart_of_account/list.blade.php ENDPATH**/ ?>