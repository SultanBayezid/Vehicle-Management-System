

<?php $__env->startSection('content'); ?>
<div class="container">
        <h1 class="display-4">Vehicles</h1>

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('income.index')); ?>">Vehicles</a></li>
                <li class="breadcrumb-item active" aria-current="page">Vehicles</li>
            </ol>
        </nav>

        <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Make</th>
                                            <th>Model</th>
                                            <th>Year</th>
                                            <th>Color</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                        <th>Name</th>
                                            <th>Make</th>
                                            <th>Model</th>
                                            <th>Year</th>
                                            <th>Color</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($vehicle->name); ?></td>
                                            <td><?php echo e($vehicle->make); ?></td>
                                            <td><?php echo e($vehicle->model); ?></td>
                                            <td><?php echo e($vehicle->year); ?></td>
                                            <td><?php echo e($vehicle->color); ?></td>
                                            <td>
                                            <div class="btn-group" role="group" aria-label="Basic example"> 
                <a href="<?php echo e(route('vehicles.show', $vehicle->id)); ?>" class="btn btn-info btn-sm"><i class="fas fa-eye"></i></a>
                <a href="<?php echo e(route('vehicles.edit', $vehicle->id)); ?>" class="btn btn-warning btn-sm"><i class="fas fa-pen"></i></a>
                <form method="POST" action="<?php echo e(route('vehicles.destroy', $vehicle->id)); ?>" >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this vehicle?')"><i class="fas fa-trash"></i></button>
                    </div> </form>
            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                             
                                    </tbody>
                                </table>
                            </div>
                 
 </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/vehicles/index.blade.php ENDPATH**/ ?>