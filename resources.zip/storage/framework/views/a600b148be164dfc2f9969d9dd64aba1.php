<?php $__env->startSection('content'); ?>
<div class="container">
        <h1 class="display-4">Income Create</h1>

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item active"  aria-current="page">Accounts</li>
                <li class="breadcrumb-item active"  aria-current="page">Transactions</li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('income.index')); ?>">Income/Deposit</a></li>
                <li class="breadcrumb-item active" aria-current="page">Income Create</li>
            </ol>
        </nav>
<div class="row">
    <div class="col-md-12">
      
      

            <div class="card-body">
                <form method="post" class="validate" autocomplete="off" action="<?php echo e(route('income.store')); ?>"
                    enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>


                    <div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label class="control-label"><?php echo e(('Date')); ?></label>
            <input type="date" class="form-control datepicker" name="trans_date" value="<?php echo e(old('trans_date')); ?>" required>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label class="control-label"><?php echo e(('Account')); ?></label>
            <select class="form-control select2-ajax" data-value="id" data-display="account_title" data-table="accounts" data-where="1" name="account_id" id="account_id" required>
                <option value=""><?php echo e(('Select One')); ?></option>
                <?php echo e(create_option("accounts", "id", "account_title", old('account_id'))); ?>

            </select>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label class="control-label"><?php echo e(('Income Type')); ?></label>
            <select class="form-control select2-ajax" data-value="id" data-display="name" data-table="chart_of_accounts" data-where="3" name="chart_id" required>
                <option value=""><?php echo e(('Select One')); ?></option>
                <?php echo e(create_option("chart_of_accounts", "id", "name", old('chart_id'), array("type=" => "income"))); ?>

            </select>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label class="control-label"><?php echo e(('Amount')." ".currency()); ?></label>
            <input type="text" class="form-control float-field" name="amount" value="<?php echo e(old('amount')); ?>" required>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label class="control-label"><?php echo e(('Payer')); ?></label>
            <select class="form-control select2-ajax" data-value="id" data-display="contact_name" data-table="contacts" data-where="1" name="payer_payee_id">
                <option value=""><?php echo e(('Select One')); ?></option>
                <?php echo e(create_option("contacts", "id", "contact_name", old('payer_payee_id'))); ?>

            </select>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label class="control-label"><?php echo e(('Payment Method')); ?></label>
            <select class="form-control select2-ajax" data-value="id" data-display="name" data-table="payment_methods" data-where="1" name="payment_method_id" required>
                <option value=""><?php echo e(('Select One')); ?></option>
                <?php echo e(create_option("payment_methods", "id", "name", old('payment_method_id'))); ?>

            </select>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label class="control-label"><?php echo e(('Reference')); ?></label>
            <input type="text" class="form-control" name="reference" value="<?php echo e(old('reference')); ?>">
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label class="control-label"><?php echo e(('Attachment')); ?></label>
            <input type="file" class="form-control trickycode-file" name="attachment">
        </div>
    </div>

    <div class="col-md-12">
        <div class="form-group">
            <label class="control-label"><?php echo e(('Note')); ?></label>
            <textarea class="form-control" name="note"><?php echo e(old('note')); ?></textarea>
        </div>
    </div>

    <div class="col-md-12">
        <div class="form-group">
            <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-file"></i> <?php echo e(('Save Changes')); ?></button>
        </div>
    </div>
</div>

                </form>
            </div>
       
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/income/create.blade.php ENDPATH**/ ?>