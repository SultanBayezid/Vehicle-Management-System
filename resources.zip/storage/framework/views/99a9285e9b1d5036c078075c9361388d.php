
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-2 pt-3 text-gray-800">Dashboard</h1>

    <!-- Content Row -->
    <div class="row">
    <?php
$tripsall = App\Models\Trip::All();
$vehicles = App\Models\Vehicle::All();
$vehiclescount = $vehicles->count();
$tripCount = $tripsall->count();
?>
        <!-- Widgets -->
        <div class="col-lg-3 col-md-6">
            <div class="card shadow mb-4">
                <div class="card-body">
                    <div class="row">
                        <div class="col-3">
                            <i class="fas fa-road fa-2x text-primary"></i>
                        </div>
                        <div class="col-9 text-right">
                            <div class="h5 mb-0 font-weight-bold text-gray-800">Trips</div>
                            <div class="h3 mb-0 font-weight-bold text-gray-800"><?php echo e($tripCount); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6">
            <div class="card shadow mb-4">
                <div class="card-body">
                    <div class="row">
                        <div class="col-3">
                            <i class="fas fa-chart-bar fa-2x text-success"></i>
                        </div>
                        <div class="col-9 text-right">
                            <div class="h5 mb-0 font-weight-bold text-gray-800">Revenue</div>
                            <div class="h3 mb-0 font-weight-bold text-gray-800">৳<?php echo e(current_month_income()); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6">
            <div class="card shadow mb-4">
                <div class="card-body">
                    <div class="row">
                        <div class="col-3">
                            <i class="fas fa-chart-pie fa-2x text-info"></i>
                        </div>
                        <div class="col-9 text-right">
                            <div class="h5 mb-0 font-weight-bold text-gray-800">Expenses</div>
                            <div class="h3 mb-0 font-weight-bold text-gray-800">৳<?php echo e(current_month_expense()); ?></div>
                
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6">
            <div class="card shadow mb-4">
                <div class="card-body">
                    <div class="row">
                        <div class="col-3">
                            <i class="fas fa-car fa-2x text-warning"></i>
                        </div>
                        <div class="col-9 text-right">
                            <div class="h5 mb-0 font-weight-bold text-gray-800">Vehicles</div>
                            <div class="h3 mb-0 font-weight-bold text-gray-800"><?php echo e($vehiclescount); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Row -->
    <div class="row">
        <!-- Line Chart -->
        <div class="col-lg-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Line Chart</h6>
                </div>
                <div class="card-body">
                    <canvas id="lineChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Bar Chart -->
        <div class="col-lg-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Bar Chart</h6>
                </div>
                <div class="card-body">
                    <canvas id="barChart"></canvas>
                </div>
            </div>
        </div>
    </div>
   <?php
   $trips =  App\Models\Trip::limit(5)->get();
   ?>
    <!-- Table Row -->
    <div class="row">
        <div class="col-lg-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Trips</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="datatablesSimple" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Pickup Location</th>
                                    <th>Dropoff Location</th>
                                    <th>Driver</th>
                                    <th>Vehicle</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route('trips.show', $trip->id)); ?>"><?php echo e($trip->trip_date); ?></a></td>
                                    <td><?php echo e($trip->pickup_location); ?></td>
                                    <td><?php echo e($trip->dropoff_location); ?></td>
                                    <td><?php echo e($trip->driver->name); ?></td>
                                    <td><?php echo e($trip->vehicle->name); ?></td>
                                    <td><span class="badge badge-success">Active</span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- Add more table rows as needed -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Include charting libraries and script initialization here -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
<script>
    // JavaScript code for chart initialization and data
    // Replace with your actual chart data and initialization logic
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>