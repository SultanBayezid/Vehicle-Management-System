@extends('backend.layouts.header')
@section('content') 


<div class="container">
  <h1 class="display-4">{{$vehicle->name}}</h1>
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="{{route('home')}}">Home</a>
      </li>
      <li class="breadcrumb-item">
        <a href="{{route('vehicles.index')}}">Vehicles</a>
      </li>
      <li class="breadcrumb-item " aria-current="page">{{$vehicle->name}}</li>
      <li class="breadcrumb-item active">{{ _lang('Issue') }}</li>
    </ol>
  </nav>
  <div class="card">
    <div class="card-body">
      <div class="row">
      <div class="col-md-2 col-sm-4 borderright">
   @include('backend.vehicles.menu')

      </div>
      <div class="col-md-10 col-sm-8">
      <span>
    <h1 class="display-6" style="display: inline-block;">Issues</h1>
    <button class="btn btn-primary btn-sm" style="float: right;"  data-toggle="modal" data-target="#issue"><i class="fas fa-plus"></i> Add New Issue</button>
</span>
        <table id="datatablesSimple">
          <thead>
            <tr>
              <th>Piority</th>
              <th>Driver</th>
              <th>Summary</th>
              <th>Reported Date</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>Piority</th>
              <th>Driver</th>
              <th>Summary</th>
              <th>Reported Date</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </tfoot>
          <tbody> @foreach($issues as $issue) <tr>
              <td>{{$issue->priority }}</td>
              <td>{{$issue->driver->name }}</td>
              <td>{{$issue->summary }}</td>
              <td>{{$issue->report_date }}</td>
              <td>@if ($issue->status == 1) <div class="badge badge-danger">Pending</div> @elseif ($issue->status == 2) <div class="badge badge-warning">Closed</div> @elseif ($issue->status == 3) <div class="badge badge-success">Resolved</div> @else Status: Unknown @endif </td>
              <td>
                <div class="btn-group" role="group" aria-label="Basic example">
                <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editModal{{$issue->id}}">  <i class="fas fa-pen"></i> </button>
            @include('backend.vehicles.issues.modal.edit') 

                <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#showModal{{$issue->id}}">
                <i class="fas fa-eye"></i></button>

            @include('backend.vehicles.issues.modal.view') 


                  <form method="POST" action="{{ route('issues.destroy', $issue->id) }}"> @csrf @method('DELETE') <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this vehicle?')">
                      <i class="fas fa-trash"></i>
                    </button>
                </div>
                </form>
              </td>
            </tr> 
            @endforeach </tbody>
        </table>
      </div>
      </div>

    </div>
  </div>

</div>
@include('backend.vehicles.issues.modal.create') 



@endsection